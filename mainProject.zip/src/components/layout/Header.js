import * as React from "react"; 
import { Link } from "react-router-dom";
// import { Modal } from "../UI";
import useDisclosure from '../Hooks/useDisclosure'
import Login from "../auth/Login";
import Register from "../auth/Register";



import  { useState } from 'react';

import 'react-responsive-modal/styles.css';

import { Modal } from 'react-responsive-modal';


export default function Header(){
  const [open, setOpen] = useState(false);

  const onOpenModal = () => setOpen(true);
  const onCloseModal = () => setOpen(false);
  const [open1, setOpen1] = useState(false);

  const onOpenModal1 = () => setOpen1(true);
  const onCloseModal1 = () => setOpen1(false);

  
  
    return(
        <>
        
    <Modal open={open} onClose={onCloseModal} dialogClassName="my-modal" styles={{'width':'50%'}} center>
        <Login/>
      </Modal>
    
    <Modal open={open1} onClose={onCloseModal1}  center>
        <Register/>
      </Modal>
    

  <nav class="navbar navbar-default navbar-trans navbar-expand-lg fixed-top">
    <div class="container">
      <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarDefault" aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span></span>
        <span></span>
        <span></span>
      </button>
      <a class="navbar-brand text-brand" href="index.html">Room<span class="color-b">Ninja</span></a>

       <div class="navbar-collapse collapse justify-content-center" id="navbarDefault">
        <ul class="navbar-nav">
      
        <li class="nav-item">
          <Link class="nav-link " to="/home">Home</Link>
          </li>

          <li class="nav-item">
            <Link class="nav-link " to="/about">About</Link>
          </li>
        
          <li class="nav-item">
            <Link class="nav-link " to="/Property">PG</Link>
          </li>


       
          <li class="nav-item">
            <Link class="nav-link " to="/contact">Contact</Link>
          </li>
          
          
      <li class="nav-item dropdown">
            <Link class="nav-link dropdown-toggle" to="/dashboard" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dashboard</Link>
            <div class="dropdown-menu">
              <Link class="dropdown-item " to="/booking">Booking table</Link>
              <Link class="dropdown-item " to="/city">City</Link>
              
              <Link class="dropdown-item " to="/addcategory">Add Category</Link>
              
              <Link class="dropdown-item " to="managecategory">Manage Category</Link>
              <Link class="dropdown-item " to="/updatecategory">Update Category</Link>
              <Link class="dropdown-item " to="/addcity"> Add City</Link>
              <Link class="dropdown-item " to="/managecity">Manage City</Link>
              <Link class="dropdown-item " to="/updatecity">Update City</Link>
              <Link class="dropdown-item " to="/addroom">Add Room</Link>
              <Link class="dropdown-item " to="/manageroom">Manage Room</Link>
              <Link class="dropdown-item " to="/updateroom">Update Room</Link>
              <Link class="dropdown-item " to="/viewfeedback">View Feedback</Link>
              <Link class="dropdown-item " to="/viewcontact">View Contact</Link>
            </div>
          </li>
          <li class="nav-item">
            <Link class="nav-link " onClick={onOpenModal} >Log in</Link>
      
          </li>
          <li class="nav-item">
            <Link class="nav-link " onClick={onOpenModal1}>Register</Link>
      
          </li>
          <li class="nav-item">
            <Link class="nav-link " to="/bookingrequest">Booking</Link>
      
          </li>
          
       
        </ul>
      </div>

  <Link to='/search'>    <button type="button" class="btn btn-b-n " data-bs-toggle="modal" data-bs-target="#exampleModal">
        <i class="bi bi-search"></i>
      </button></Link>

      

    </div>
   </nav>
       </>
    )
}