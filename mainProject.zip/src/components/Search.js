export default function Search(){
    return(
        <>
       

       <div class="container mt-5">
                <div class="row mt-5 logincolor">
                {/* <div class="row mt-5 bg-success"> */}
                <div class="col-md-12 col-lg-12 mt-5">
                    <div class="title-single-box mt-5">
                    <h1 class="title-single pb-3 text-center text-white">Search</h1>
                    </div>
                </div>
                </div>
                <div className="row">
                <div className="col-md-12 my-4 shadow py-5 rounded">
               <div className="row">
                    <div className="col-md-9 border ms-2">
                  
                        <form>
                        <div className="form-group row">
                               
                       <input type="text" placeholder="Enter city name" className="form-control py-3"></input>
                    
                       </div>
                       <div className="col-md d-flex ">
                      
                     
                     
                        </div>
                     
                       </form>
                      


                        </div>
                    <div className="col-md ms-2 me-2 dis border">
                    <i className="fa fa-search fa-2x mt-2"></i>
                    
                    </div>
                </div> 
                <div className="d-flex  flex-wrap">
                <div className="row mt-3 ms-1">
                <div class="p-2"><i className="fa fa-globe fa-3x"></i></div>
                <div class="p-2">Flex item</div>
                </div>
              
                <div className="row mt-3 ms-1">
                <div class="p-2"><i className="fa fa-globe fa-3x"></i></div>
                <div class="p-2">Flex item</div>
                </div>
              
                <div className="row mt-3 ms-1">
                <div class="p-2"><i className="fa fa-globe fa-3x"></i></div>
                <div class="p-2">Flex item</div>
                </div>
              
                <div className="row mt-3 ms-1">
                <div class="p-2"><i className="fa fa-globe fa-3x"></i></div>
                <div class="p-2">Flex item</div>
                </div>
              
                <div className="row mt-3 ms-1">
                <div class="p-2"><i className="fa fa-globe fa-3x"></i></div>
                <div class="p-2">Flex item</div>
                </div>
              
                <div className="row mt-3 ms-1">
                <div class="p-2"><i className="fa fa-globe fa-3x"></i></div>
                <div class="p-2">Flex item</div>
                </div>
              
                <div className="row mt-3 ms-1">
                <div class="p-2"><i className="fa fa-globe fa-3x"></i></div>
                <div class="p-2">Flex item</div>
                </div>
              
                <div className="row mt-3 ms-1">
                <div class="p-2"><i className="fa fa-globe fa-3x"></i></div>
                <div class="p-2">Flex item</div>
                </div>
              
                <div className="row mt-3 ms-1">
                <div class="p-2"><i className="fa fa-globe fa-3x"></i></div>
                <div class="p-2">Flex item</div>
                </div>
              
                <div className="row mt-3 ms-1">
                <div class="p-2"><i className="fa fa-globe fa-3x"></i></div>
                <div class="p-2">Flex item</div>
                </div>
              
                <div className="row mt-3 ms-1">
                <div class="p-2"><i className="fa fa-globe fa-3x"></i></div>
                <div class="p-2">Flex item</div>
                </div>
              

                </div>
                </div>
                </div>
            </div>
            
           
        </>
    )
}