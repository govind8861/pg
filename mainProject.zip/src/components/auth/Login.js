import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { ToastContainer,toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css';
import { Link } from "react-router-dom";
import CustomInput from "../layout/CustomInput";
import {  signInWithEmailAndPassword,signInWithPopup } from 'firebase/auth';
import { auth,googleProvider } from "../Firebase";
import ForgotPAssword from "../ForgotPassword";



import { FiEye, FiEyeOff } from "react-icons/fi";


export default function Login(){
    const nav = useNavigate()
    const[email,setEmail]= useState("")
    const[pass,setPass]= useState("")
    const [isLogin, setIsLogin] = useState(false)
    
    const [showPassword, setShowPassword] = useState(false);
    // const handleform =(data)=>{
    //     data.preventDefault()
    //     if(email =="govindmaurya8699@gmail.com" && pass=="gobind"){
    //         nav('/register')
    //             toast("Succsefully login")
    //         console.log("successful")
    //     }else{
    //         console.log("unsuccess")
    //         toast("error occured")
    //     }

    // }
    const handleSubmit = async (e) => {
        e.preventDefault()
            await signInWithEmailAndPassword(auth, email, pass)
                .then((userCredential) => {
                    // Signed in
                    const user = userCredential.user;
                    alert("Login Successful")
                    nav("/home")
                    // console.log(user);
                })
                .catch((error) => {
                    const errorCode = error.code;
                    const errorMessage = error.message;
                    console.log(errorCode, errorMessage)
                    alert("error")
                });
        // else await createUserWithEmailAndPassword(auth, email, password)
        //     .then((userCredential) => {
        //         // Signed in
        //         const user = userCredential.user;
        //         console.log(user);
        //         alert("User Created")
        //         setIsLogin(true)

        //         // ...
        //     })
        //     .catch((error) => {
        //         const errorCode = error.code;
        //         const errorMessage = error.message;
        //         console.log(errorCode, errorMessage);
        //         alert("Error: " + errorMessage)
        //         // ..
        //     });
    }
    
    const handleTogglePassword = () => {
        setShowPassword((prevShowPassword) => !prevShowPassword);
      };
    
      const handlePasswordChange = (data) => {
        setPass(data.target.value)
    };
    const signInWithGoogle = async () => {
        try {
        await signInWithPopup(auth,googleProvider);
        } catch (err){
          console.error(err);
        }
      };
      
   
    const handleButtonClick = () =>{

    }
    return(
        <>
            <div class="container-fluid ">
                <div class="row mt-5 logincolor">
                {/* <div class="row mt-5 bg-success"> */}
                <div class="col-md col-lg mt-5">
                    <div class="title-single-box mt-5">
                    <h1 class="title-single pb-3 text-center text-white">Sign in</h1>
                    </div>
                </div>
                </div>
                <div className="row">
                <div className="col-md-12 my-5 py-5 rounded">
                <form onSubmit={handleSubmit} >
                    <div class="form-group">
                        <label className="py-3">Email Address</label>
                        <input type="email" class="form-control mb-1 rounded-pill" id="addcategory"  placeholder="enter your email here" required onChange={(data)=>{setEmail(data.target.value)}} />
                     </div>
                    <div class="form-group">
                        <label className="py-3">Password</label>
                        {/* <input type="password" class="form-control mb-4 rounded-pill" id="addcategory"  placeholder="enter your password here" required
                          onChange={(data)=>{setPass(data.target.value)}}/> */}
                          <CustomInput value={pass}  onChange={handlePasswordChange} />

     
                     </div>
                    
                    <button type="submit" class="btn btn-success mx-auto d-block mt-4">Submit</button>
                </form>
                	
                
                     <div class="form-group row mt-3">
                      <button type='button' className="btn btn-link text " ><Link to='/forgot'>Forgot Password</Link></button>
                

                            </div>                   
                    <span>Don't have an account?<Link to='/register'> Register</Link></span>
                    <br/>
                    <button onClick={signInWithGoogle} className="btn btn">Sign in with Google</button>
        
                
                </div>
                </div>
             </div>
        
            <ToastContainer/>
			
          
        </>
    )
}