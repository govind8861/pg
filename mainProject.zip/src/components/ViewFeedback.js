
export default function ViewFeedback(){
    const data=[
        {
            city:'jalandhar',state:'punjab',feedback:'1st feedback my name is gobind morya and i am here to give a feedback for the pg room in which i have lived for month i really enjoed there and i want more person to enjoy this.',uid:'101',createdAt:'1/1/2023'
        },
        {
            city:'gorakhpur',state:'up',feedback:'1st feedback',uid:'102',createdAt:'1/1/2023'
        },
        {
            city:'jalandhar',state:'punjab',feedback:'1st feedback',uid:'103',createdAt:'1/1/2023'
        },
        {
            city:'jalandhar',state:'punjab',feedback:'1st feedback',uid:'104',createdAt:'1/1/2023'
        },
        {
            city:'jalandhar',state:'punjab',feedback:'1st feedback',uid:'105',createdAt:'1/1/2023'
        },
    ]
 
    return(
        
        <>
          <div class="container mt-5">
                <div class="row mt-5 logincolor">
                <div class="col-md-12 mt-5 col-lg-12">
                    <div class="mt-5">
                    <h1 class="pb-4 p-1 text-white text-center">Feedback</h1>
                    </div>
                </div>
              
                </div>
            </div>
            <div className="container">
                <div className="row mt-4">
               
               <table className="table table-striped">
                <thead className="table-dark">
                 <tr>
                    
                    <th>id</th>
                    <th>Category</th>
                    <th>Rooms</th>
                    <th>Feedback</th>
                    <th>UID</th>
                    <th>Created_at</th>
                </tr>
                </thead>
                <tbody>
                    {data.map((element,index)=>(
                             <tr >
                    
                             <td>{index+1}</td>
                             <td>{element.city}</td>
                             <td>{element.state}</td>

                             <td>{element.feedback}</td>
                             <td>{element.uid}</td>
                             <td>{element.createdAt}</td>
                            
                         </tr>
                    ))
                    }
               
                </tbody>
                </table>
                </div>
                </div>
            
        </>
    )
}