export { default as Modal } from './Modal'
// READ THIS -- https://stackoverflow.com/questions/34072598/es6-exporting-importing-in-index-file
