
import Login from '../auth/Login';

export default function Modal1(){
  
    return(
        <>
            <div>
      <button onClick={onOpenModal}>Open modal</button>
    </div>
  
        </>
    )
}