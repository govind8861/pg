<script>
    .img{
    
    }
</script>